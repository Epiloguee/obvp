<?php
$servername = "localhost";
$username = "zhilyo8l_cert_db";
$password = "A543312a";
$dbname = "zhilyo8l_cert_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$certificate_id = intval($_GET['certificate_id']);
$sql = "SELECT stock FROM certificates WHERE id = $certificate_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo $row['stock'];
} else {
    echo "0";
}

$conn->close();
?>