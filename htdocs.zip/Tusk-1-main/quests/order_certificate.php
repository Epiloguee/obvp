<?php
$host = 'localhost';
$user = 'zhilyo8l_cert_db';
$password = 'A543312a';
$database = 'zhilyo8l_cert_db';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$certificate_id = (int)$_POST['certificate_id'];
$phone = $conn->real_escape_string($_POST['phone']);
$email = $conn->real_escape_string($_POST['email']);
$quantity = (int)$_POST['quantity'];

$result = $conn->query("SELECT stock FROM certificates WHERE id = $certificate_id");
$row = $result->fetch_assoc();

if ($row['stock'] >= $quantity) {
    $new_stock = $row['stock'] - $quantity;
    $conn->query("UPDATE certificates SET stock = $new_stock WHERE id = $certificate_id");
    $conn->query("INSERT INTO certificate_orders (phone, email, quantity, certificate_id) VALUES ('$phone', '$email', $quantity, $certificate_id)");
    echo "Ваш заказ принят!";
} else {
    echo "Недостаточно сертификатов в наличии.";
}

$conn->close();
?>