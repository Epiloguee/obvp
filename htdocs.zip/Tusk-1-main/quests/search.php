<?php

header('Content-Type: text/plain;charset=utf-8');

$conn = new mysqli('localhost', 'zhilyo8l_cert_db', 'A543312a', 'zhilyo8l_cert_db');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = $_GET['query'];

// Защита от SQL-инъекций
$query = $conn->real_escape_string($query);

// Поиск сертификатов
$sql = "SELECT * FROM certificates WHERE name LIKE '%$query%'";
$result = $conn->query($sql);

// Вывод результатов
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo " Сертификат: " . $row['name'] . " - " . $row['price'] . " руб. - В наличии: " . $row['stock'] . "";
    }
} else {
    echo "Нет результатов.";
}

$conn->close();
?>