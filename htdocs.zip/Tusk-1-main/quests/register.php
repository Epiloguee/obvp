<?php

header('Content-Type: text/plain;charset=utf-8');

// Подключение к базе данных
$servername = "localhost";
$username = "zhilyo8l_reg_db";
$password = "A543312a";
$dbname = "zhilyo8l_reg_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение данных из формы
$user = $_POST['username'];
$pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

// Вставка данных в базу
$sql = "INSERT INTO users (username, password) VALUES ('$user', '$pass')";

if ($conn->query($sql) === TRUE) {
    session_start();
    $_SESSION['username'] = $user;
    header("Location: profile.html");
    exit();
} else {
    echo "Ой, кажется, возникла ошибка: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>