<?php

header('Content-Type: text/plain;charset=utf-8');

session_start();

// Подключение к базе данных
$servername = "localhost";
$username = "zhilyo8l_reg_db";
$password = "A543312a";
$dbname = "zhilyo8l_reg_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение данных из формы
$user = $_POST['username'];
$pass = $_POST['password'];

// Проверка данных
$sql = "SELECT * FROM users WHERE username='$user'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($pass, $row['password'])) {
        $_SESSION['username'] = $user;
        header("Location: profile.html");
        exit();
    } else {
        echo "Неверный логин или пароль!";
    }
} else {
    echo "Неверный логин или пароль!";
}

$conn->close();
?>