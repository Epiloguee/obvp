-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Июн 11 2024 г., 12:54
-- Версия сервера: 10.4.32-MariaDB
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `user_registration`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'Geralt', '$2y$10$8g0l7hbDhD4HmSpfZ7t/G.r8q4gOg0Oky4b0Xx/NFh4ublHArHJqK'),
(3, 'Godless', '$2y$10$0MT4d5eGlGTiKkEeRwkpBealIyLcTHl48fnedNsWgM134W6gx3V.i'),
(5, 'Owin', '$2y$10$7eBK39esuFL37NC7mFaxPepLCEKR/1E7ze/L.x3LatHzhtT2XXUZe'),
(6, 'Vortex', '$2y$10$1BigmnsgPHrIufXn8JM.vupY9z5KRTOYIfsoEE6KKnQjw6uYN2YFO'),
(7, 'Sunshine', '$2y$10$3dkwRS1UG.17x.Cld0C.Culawj0FbxHxODsjrPuLCqlksgYQR4hUi'),
(8, 'Popper1246', '$2y$10$zD.F6B53Kua/tkhllaNF/eTzBWHi6t/4FygON6fuD3AwRSJqPJYGu');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
