<?php
session_start();
include('configM.php'); // Подключение к базе MySQL

if (!empty($_GET['id'])) {
    $user_id = intval($_GET['id']);
    $sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    echo "Пользователь удалён!";
}
header("Location: users.php");
exit();
?>
