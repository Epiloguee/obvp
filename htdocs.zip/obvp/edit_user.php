<?php
session_start();
include('configM.php');

// Проверка авторизации пользователя
if (!isset($_SESSION['user'])) {
    header("Location: index.php"); // Перенаправление на страницу входа
    exit();
}

// Получение ID пользователя
$user_id = $_SESSION['user']['id'] ?? null;

if (!$user_id) {
    echo "Ошибка: пользователь не найден в сессии.";
    exit();
}

// Обработка данных из формы
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_data = $_POST['new_data'] ?? '';
    $sql_update = "UPDATE users SET data = ? WHERE id = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("si", $new_data, $user_id);

    if ($stmt_update->execute()) {
        echo "Данные успешно обновлены!";
    } else {
        echo "Ошибка обновления данных.";
    }
    $stmt_update->close();
}

// Загрузка данных пользователя
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "Ошибка: пользователь с таким ID не найден.";
    exit();
}

$stmt->close();
$conn->close();
?>

<?php include('header.php'); ?>

<h2>Редактирование данных пользователя</h2>
<form method="POST">
    <label for="new_data">Данные:</label>
    <input type="text" name="new_data" value="<?php echo $user['data'] ?? ''; ?>" required>
    <button type="submit">Сохранить</button>
</form>

<?php include('footer.php'); ?>
