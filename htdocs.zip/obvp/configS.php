<?php
$db_path = 'database.sqlite';
$conn = new PDO("sqlite:$db_path");
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>
