<?php
include('configM.php'); // или configS.php

// Получение данных из формы
$email = $_POST['email'];
$password = hash('sha1', hash('md5', $_POST['password'])); // Двойное хеширование пароля

// Проверка существования пользователя
$sql_check = "SELECT * FROM users WHERE email = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("s", $email);
$stmt_check->execute();
$result = $stmt_check->get_result();

if ($result->num_rows > 0) {
    // Если пользователь уже существует
    echo "Пользователь с таким Email уже существует.";
} else {
    // Добавление нового пользователя
    $sql_insert = "INSERT INTO users (email, password) VALUES (?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("ss", $email, $password);
    
    if ($stmt_insert->execute()) {
        echo "Регистрация прошла успешно!";
    } else {
        echo "Ошибка при регистрации. Попробуйте ещё раз.";
    }

    $stmt_insert->close();
}

$stmt_check->close();
$conn->close();
?>