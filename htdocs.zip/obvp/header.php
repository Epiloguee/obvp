<header>
    <h1>Добро пожаловать</h1>
    <?php
    session_start();
    if (isset($_SESSION['user'])) {
        echo "<p>Вы вошли как: " . $_SESSION['user']['email'] . "</p>";
        echo '<a href="profile.php">Профиль</a> | ';
        echo '<a href="logout.php">Выйти</a>';
    } else {
        echo '<a href="index.php">Войти</a>';
    }
    ?>
</header>
