<?php include('header.php'); ?>
<form action="auth_handler.php" method="POST">
    <label for="email">Email:</label>
    <input type="email" name="email" required>
    <label for="password">Пароль:</label>
    <input type="password" name="password" required>
    <button type="submit">Войти</button>
</form>
<a href="register.php">Зарегистрироваться</a>
<?php include('footer.php'); ?>
