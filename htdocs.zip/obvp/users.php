<?php
session_start();
include('configM.php'); // Подключение к базе MySQL

// Поиск данных в таблице
$search_query = "SELECT * FROM users";
$search_params = [];

if (!empty($_GET['search'])) {
    $search = "%" . $_GET['search'] . "%";
    $search_query = "SELECT * FROM users WHERE email LIKE ? OR data LIKE ?";
    $search_params = [$search, $search];
}

$stmt = $conn->prepare($search_query);
if ($search_params) {
    $stmt->bind_param("ss", ...$search_params);
}
$stmt->execute();
$result = $stmt->get_result();

?>

<?php include('header.php'); ?>

<h2>Список пользователей</h2>
<a href="register.php">Добавить новую запись</a>
<form method="GET">
    <input type="text" name="search" placeholder="Поиск" value="<?php echo $_GET['search'] ?? ''; ?>">
    <button type="submit">Найти</button>
</form>

<table border="1">
    <tr>
        <th>ID</th>
        <th>Email</th>
        <th>Дата регистрации</th>
        <th>Действия</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo date("d.m.Y H:i", strtotime($row['data'])); ?></td>
            <td>
                <a href="edit_user.php?id=<?php echo $row['id']; ?>">Редактировать</a> | 
                <a href="delete_user.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Удалить пользователя?');">Удалить</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<a href="register.php">Добавить новую запись</a>

<?php include('footer.php'); ?>
