<?php
session_start();
include('configM.php'); // Подключение к базе данных

// Проверка, авторизован ли пользователь
if (!isset($_SESSION['user'])) {
    header("Location: index.php"); // Перенаправление на страницу входа
    exit();
}

// Получение ID пользователя из сессии
$user_id = $_SESSION['user']['id'];

// Загрузка данных пользователя
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "Ошибка: пользователь с таким ID не найден.";
    exit();
}

// Обработка данных из формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];
    $photo = $_FILES['photo'];
    $filename = $user['photo']; // Сохраняем имя файла из БД по умолчанию

    if ($photo['error'] === 0) {
        // Генерация уникального имени файла
        $filename = $user_id . '_' . time() . '.jpg';
        $upload_dir = "uploads/";
        $thumb_dir = "uploads/thumbs/";
        $upload_path = $upload_dir . $filename;
        $thumb_path = $thumb_dir . $filename;

        // Перемещение загруженного файла
        move_uploaded_file($photo['tmp_name'], $upload_path);

        // Проверка наличия модуля GD
        if (function_exists('imagecreatefromjpeg')) {
            // Создание миниатюры
            $image = imagecreatefromjpeg($upload_path);
            $thumb = imagescale($image, 100, 100);
            imagejpeg($thumb, $thumb_path);
        } else {
            echo "Ошибка: не установлен модуль GD для работы с изображениями.";
            exit();
        }
    }

    // Обновление данных в БД
    $sql_update = "UPDATE users SET status = ?, photo = ? WHERE id = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ssi", $status, $filename, $user_id);
    $stmt_update->execute();

    // Обновляем данные в сессии
    $_SESSION['user']['photo'] = $filename;
    $_SESSION['user']['status'] = $status;

    echo "Данные успешно обновлены!";
}

$stmt->close();
$conn->close();
?>

<?php include('header.php'); ?>

<h2>Личный кабинет</h2>

<form method="POST" enctype="multipart/form-data">
    <label>Статус:</label>
    <select name="status">
        <option value="active" <?php if ($user['status'] == 'active') echo 'selected'; ?>>Активный</option>
        <option value="inactive" <?php if ($user['status'] == 'inactive') echo 'selected'; ?>>Неактивный</option>
    </select>
    <br><br>

    <label>Фотография:</label>
    <input type="file" name="photo">
    <br><br>

    <button type="submit">Сохранить</button>
</form>

<?php if ($user['photo']): ?>
    <h3>Текущая фотография:</h3>
    <img src="uploads/<?php echo $user['photo']; ?>" alt="Фотография пользователя" width="200">
    <h3>Миниатюра:</h3>
    <img src="uploads/thumbs/<?php echo $user['photo']; ?>" alt="Миниатюра" width="100">
<?php endif; ?>

<?php include('footer.php'); ?>
