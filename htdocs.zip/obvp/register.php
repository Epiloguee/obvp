<?php include('header.php'); ?>
<form action="register_handler.php" method="POST">
    <label for="email">Email:</label>
    <input type="email" name="email" required>
    <label for="password">Пароль:</label>
    <input type="password" name="password" required>
    <button type="submit">Зарегистрироваться</button>
</form>
<?php include('footer.php'); ?>
