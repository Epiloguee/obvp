<?php
session_start();
include('configM.php');

$email = $_POST['email'];
$password = hash('sha1', hash('md5', $_POST['password']));

$sql = "SELECT * FROM users WHERE email = ? AND password = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $email, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $_SESSION['user'] = $result->fetch_assoc();
    header("Location: users.php");
} else {
    echo "Неверный email или пароль.";
}
$stmt->close();
$conn->close();
?>
