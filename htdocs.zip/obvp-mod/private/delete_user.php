<?php
require_once '../config/configM.php';

if (!isset($_GET['id'])) {
    die("ID пользователя не указан.");
}

$id = $_GET['id'];
$stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
$stmt->execute([$id]);

header("Location: ../public/users.php");
