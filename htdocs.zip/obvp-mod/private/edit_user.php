<?php
session_start();
require_once '../config/configM.php';

if (!isset($_GET['id'])) {
    die("ID пользователя не указан.");
}

$id = $_GET['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare("UPDATE users SET name = ?, status = ? WHERE id = ?");
    $stmt->execute([$name, $status, $id]);

    header("Location: ../public/users.php");
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<h1>Редактирование пользователя</h1>
<form method="post">
    <label>Имя:</label>
    <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
    <label>Статус:</label>
    <select name="status">
        <option value="active" <?= $user['status'] === 'active' ? 'selected' : '' ?>>Активный</option>
        <option value="inactive" <?= $user['status'] === 'inactive' ? 'selected' : '' ?>>Неактивный</option>
    </select>
    <button type="submit">Сохранить</button>
</form>
<a href="../public/users.php">Назад</a>
