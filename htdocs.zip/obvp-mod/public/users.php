<?php
session_start();
require_once '../config/configM.php';

$stmt = $pdo->query("SELECT * FROM users");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h1>Список пользователей</h1>
<table>
    <tr>
        <th>Email</th>
        <th>Дата регистрации</th>
        <th>Действия</th>
    </tr>
    <?php foreach ($users as $user): ?>
        <tr>
            <td><img src="../uploads/thumbs/<?= htmlspecialchars($user['photo']) ?>" alt="Фото"></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
            <td><?= htmlspecialchars($user['reg_date']) ?></td>
            <td>
                <a href="edit_user.php?id=<?= $user['id'] ?>">Редактировать</a>
                <a href="delete_user.php?id=<?= $user['id'] ?>" onclick="return confirm('Удалить пользователя?')">Удалить</a>
            </td>

        </tr>
    <?php endforeach; ?>
</table>
<a href="register.php">Добавить нового пользователя</a>