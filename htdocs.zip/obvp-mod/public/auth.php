<?php
session_start();
require_once '../config/configM.php';

$email = $_POST['email'];
$password = $_POST['password'];

// Проверяем пользователя в базе данных
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_email'] = $user['email'];
    header("Location: users.php");
} else {
    echo "Неверный логин или пароль. <a href='index.php'>Попробовать снова</a>";
}
