<?php
session_start();
header("Content-Type: image/svg+xml");

$n = rand(1, 9);
$_SESSION['captcha_value'] = $n;

echo "<svg width='200' height='200' xmlns='http://www.w3.org/2000/svg'>";
for ($i = 0; $i < $n; $i++) {
    $x = rand(10, 190);
    $y = rand(10, 190);
    $r = rand(10, 50);
    $color = sprintf("#%06X", rand(0, 0xFFFFFF));
    echo "<circle cx='$x' cy='$y' r='$r' fill='$color' fill-opacity='0.5'/>";
}
echo "</svg>";
