<?php
session_start();
require_once '../templates/header.php';
?>

<h1>Добро пожаловать!</h1>
<form action="auth.php" method="post">
    <label>Email:</label>
    <input type="email" name="email" required>
    <label>Пароль:</label>
    <input type="password" name="password" required>
    <button type="submit">Войти</button>
</form>
<p>Нет аккаунта? <a href="register.php">Зарегистрироваться</a></p>

<?php require_once '../templates/footer.php'; ?>
