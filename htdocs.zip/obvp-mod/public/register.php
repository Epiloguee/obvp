<?php
require_once '../config/configM.php'; // Подключение MySQL
?>

<h1>Регистрация</h1>
<form action="register_handler.php" method="post">
    <label>Email:</label>
    <input type="email" name="email" required>
    <label>Пароль:</label>
    <input type="password" name="password" required>
    <label>Повторите пароль:</label>
    <input type="password" name="password_confirm" required>
    <label>Фотография:</label>
    <input type="file" name="photo" accept="image/*">
    <img src="captcha/generate.php" alt="CAPTCHA">
    <label>Введите количество кругов:</label>
    <input type="text" name="captcha" required>
    <button type="submit">Зарегистрироваться</button>
</form>