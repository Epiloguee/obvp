<?php
session_start();
require_once '../config/configM.php'; // Подключение базы данных MySQL

// Проверка CAPTCHA
if ($_POST['captcha'] != $_SESSION['captcha_value']) {
    die("Ошибка CAPTCHA. Попробуйте ещё раз. <a href='register.php'>Назад</a>");
}

// Проверка совпадения паролей
if ($_POST['password'] !== $_POST['password_confirm']) {
    die("Пароли не совпадают. <a href='register.php'>Назад</a>");
}

$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_BCRYPT);

// Обработка загружаемого изображения
$photo = $_FILES['photo'];
if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $photo = $_FILES['photo'];
    $photo_name = $email . '_' . time() . '.jpg';
    $photo_path = '../uploads/' . $photo_name;

    if (!move_uploaded_file($photo['tmp_name'], $photo_path)) {
        die("Ошибка загрузки изображения.");
    }

    // Генерация миниатюры
    $thumb_path = '../uploads/thumbs/' . $photo_name;
    $image = imagecreatefromjpeg($photo_path);
    $thumb = imagescale($image, 100, 100);
    imagejpeg($thumb, $thumb_path);
    imagedestroy($image);
    imagedestroy($thumb);
} else {
    $photo_name = null; // Фото не загружено
}

// Добавление данных в базу
$stmt = $pdo->prepare("INSERT INTO users (email, password, reg_date, photo) VALUES (?, ?, NOW(), ?)");
$stmt->execute([$email, $password, $photo_name]);

echo "Регистрация успешна! <a href='index.php'>Войти</a>";
